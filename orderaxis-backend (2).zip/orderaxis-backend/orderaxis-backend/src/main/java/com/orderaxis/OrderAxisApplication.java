package com.orderaxis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrderAxisApplication {
	public static void main(String[] args) {
		SpringApplication.run(OrderAxisApplication.class, args);
	}
}