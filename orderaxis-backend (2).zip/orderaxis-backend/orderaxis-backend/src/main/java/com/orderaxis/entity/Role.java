package com.orderaxis.entity;

public enum Role {
    CUSTOMER,
    SELLER,
    ADMIN
}
